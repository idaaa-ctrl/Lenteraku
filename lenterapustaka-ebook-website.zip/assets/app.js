const BOOKS = [
  {
    id: 1,
    title: "Seni Mengelola Arus Kas & Keputusan Finansial",
    author: "Raka Pratama, Ak.",
    category: "Keuangan",
    price: 79000,
    pages: 218,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #1f5c4d 0%, #13382f 100%)",
    excerpt: "Panduan praktis menyusun anggaran bulanan, dana darurat, dan pencatatan kas pribadi yang konsisten.",
    synopsis: "Banyak orang sebenarnya memiliki penghasilan yang cukup, tetapi sering kebingungan ke mana uang mengalir di akhir bulan. Buku ini membahas langkah sederhana memisahkan pos kebutuhan, tabungan, dan pengeluaran diskresioner tanpa rumus yang rumit.",
    highlights: [
      "Kerangka pencatatan kas mingguan selama 15 menit",
      "Strategi bertahap membangun dana darurat aman",
      "Contoh lembar rekap keuangan yang mudah ditiru"
    ]
  },
  {
    id: 2,
    title: "Fokus Tenang di Tengah Tumpukan Tugas",
    author: "Sinta Maharani",
    category: "Produktivitas",
    price: 65000,
    pages: 164,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #2b4c7e 0%, #192d4d 100%)",
    excerpt: "Sistem perencanaan harian realistis untuk menyelesaikan pekerjaan prioritas tanpa mengorbankan waktu istirahat.",
    synopsis: "Alih-alih memaksakan jadwal super padat yang cepat memicu kelelahan, e-book ini memperkenalkan metode blok waktu fleksibel, pemilahan tugas berdampak tinggi, dan rutinitas penutup hari agar pikiran tetap jernih.",
    highlights: [
      "Teknik memilah tugas penting vs sekadar mendesak",
      "Rancangan rencana mingguan anti-keteteran",
      "Cara kembali fokus setelah terdistraksi"
    ]
  },
  {
    id: 3,
    title: "Membaca Ulang Pola Pikir & Kebiasaan Sehari-hari",
    author: "Dr. Hendra Gunawan",
    category: "Psikologi",
    price: 85000,
    pages: 240,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #8c4327 0%, #562614 100%)",
    excerpt: "Memahami pemicu kebiasaan, bias pengambilan keputusan, dan cara membangun perubahan kecil yang bertahan lama.",
    synopsis: "Perubahan besar jarang lahir dari tekad sesaat. Melalui pendekatan psikologi terapan yang mudah dicerna, buku ini membantu Anda mengenali pemicu otomatis dalam keseharian dan menggantinya dengan kebiasaan yang mendukung tujuan jangka panjang.",
    highlights: [
      "Mengenali isyarat pemicu dan respons kebiasaan",
      "Menghadapi keraguan saat memulai target baru",
      "Refleksi mingguan untuk menjaga konsistensi"
    ]
  },
  {
    id: 4,
    title: "Surat dari Kota Hujan & Stasiun Lama",
    author: "Ayu Lestari",
    category: "Fiksi",
    price: 59000,
    pages: 192,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #5b467a 0%, #34254a 100%)",
    excerpt: "Kumpulan cerita pendek hangat tentang persahabatan, perjalanan pulang, dan keberanian memilih arah hidup sendiri.",
    synopsis: "Berlatar sudut-sudut kota yang akrab dan suasana sore yang teduh, sembilan kisah dalam buku ini menyoroti pertemuan tak terduga, percakapan jujur antaranggota keluarga, serta keberanian berdamai dengan masa lalu.",
    highlights: [
      "9 cerita pendek utuh dengan nuansa hangat",
      "Ilustrasi pembatas bab bergaya editorial",
      "Cocok untuk bacaan santai akhir pekan"
    ]
  },
  {
    id: 5,
    title: "Fundamental Pencatatan Usaha Kecil",
    author: "Raka Pratama, Ak.",
    category: "Keuangan",
    price: 89000,
    pages: 205,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #275d43 0%, #143626 100%)",
    excerpt: "Dasar pembukuan usaha rumahan dan toko online: memisahkan modal, menghitung HPP, dan memantau laba bersih.",
    synopsis: "Banyak usaha kecil berjalan ramai namun sulit melihat untung sebenarnya karena uang pribadi dan usaha tercampur. E-book ini mengurai konsep dasar pembukuan dengan bahasa yang ramah pemula lengkap dengan studi kasus jualan produk.",
    highlights: [
      "Cara menghitung harga pokok dan margin realistis",
      "Memantau stok, piutang, dan arus kas usaha",
      "Checklist evaluasi kesehatan usaha tiap bulan"
    ]
  },
  {
    id: 6,
    title: "Catatan Ruang Kerja yang Teratur",
    author: "Dimas Santoso",
    category: "Produktivitas",
    price: 55000,
    pages: 142,
    format: "PDF + EPUB",
    gradient: "linear-gradient(145deg, #7a5c2e 0%, #473418 100%)",
    excerpt: "Menata folder digital, catatan proyek, dan alur kerja sederhana agar mudah dicari saat dibutuhkan.",
    synopsis: "File berserakan dan catatan yang tersebar di berbagai aplikasi sering membuang waktu berharga. Pelajari prinsip penamaan berkas, arsip proyek, dan sistem catatan ringkas yang tetap mudah dirawat dalam jangka panjang.",
    highlights: [
      "Struktur folder digital yang rapi dan skalabel",
      "Template catatan rapat dan riset singkat",
      "Ritual bersih-bersih digital bulanan"
    ]
  }
];

const PROMO_CODES = {
  HEMAT20: 0.2
};

const state = {
  category: "Semua",
  search: "",
  cart: [],
  promoCode: null
};

const el = {
  bookGrid: document.getElementById("bookGrid"),
  emptyState: document.getElementById("emptyState"),
  resetFilterBtn: document.getElementById("resetFilterBtn"),
  searchInput: document.getElementById("searchInput"),
  categoryPills: Array.from(document.querySelectorAll(".pill")),
  cartCount: document.getElementById("cartCount"),
  openCartBtn: document.getElementById("openCartBtn"),
  closeCartBtn: document.getElementById("closeCartBtn"),
  cartDrawer: document.getElementById("cartDrawer"),
  cartBackdrop: document.getElementById("cartBackdrop"),
  cartItems: document.getElementById("cartItems"),
  promoForm: document.getElementById("promoForm"),
  promoInput: document.getElementById("promoInput"),
  promoFeedback: document.getElementById("promoFeedback"),
  subtotalText: document.getElementById("subtotalText"),
  discountRow: document.getElementById("discountRow"),
  appliedPromoCode: document.getElementById("appliedPromoCode"),
  discountText: document.getElementById("discountText"),
  totalText: document.getElementById("totalText"),
  checkoutBtn: document.getElementById("checkoutBtn"),
  checkoutConfirmation: document.getElementById("checkoutConfirmation"),
  detailModal: document.getElementById("detailModal"),
  detailModalBackdrop: document.getElementById("detailModalBackdrop"),
  closeDetailBtn: document.getElementById("closeDetailBtn"),
  detailCategory: document.getElementById("detailCategory"),
  detailCover: document.getElementById("detailCover"),
  detailTitle: document.getElementById("detailTitle"),
  detailAuthor: document.getElementById("detailAuthor"),
  detailMeta: document.getElementById("detailMeta"),
  detailSynopsis: document.getElementById("detailSynopsis"),
  detailHighlights: document.getElementById("detailHighlights"),
  detailPrice: document.getElementById("detailPrice"),
  detailAddBtn: document.getElementById("detailAddBtn"),
  previewFeaturedBtn: document.getElementById("previewFeaturedBtn"),
  menuToggle: document.getElementById("menuToggle"),
  mobileNav: document.getElementById("mobileNav")
};

function formatRupiah(amount) {
  return "Rp" + Math.round(amount).toLocaleString("id-ID");
}

function getBookById(id) {
  return BOOKS.find((book) => book.id === Number(id));
}

function getFilteredBooks() {
  const query = state.search.trim().toLowerCase();
  return BOOKS.filter((book) => {
    const matchCategory = state.category === "Semua" || book.category === state.category;
    const matchQuery =
      !query ||
      book.title.toLowerCase().includes(query) ||
      book.author.toLowerCase().includes(query) ||
      book.category.toLowerCase().includes(query);
    return matchCategory && matchQuery;
  });
}

function renderBooks() {
  const filtered = getFilteredBooks();
  el.bookGrid.innerHTML = "";

  if (filtered.length === 0) {
    el.emptyState.hidden = false;
    return;
  }

  el.emptyState.hidden = true;

  filtered.forEach((book) => {
    const card = document.createElement("article");
    card.className = "book-card";
    card.innerHTML = `
      <div class="card-banner" style="background: ${book.gradient}">
        <span class="card-category">${book.category}</span>
        <span class="card-format">${book.pages} hlm &bull; ${book.format}</span>
      </div>
      <div class="card-body">
        <h3>${book.title}</h3>
        <p class="card-author">${book.author}</p>
        <p class="card-excerpt">${book.excerpt}</p>
        <div class="card-footer">
          <span class="card-price">${formatRupiah(book.price)}</span>
          <div class="card-actions">
            <button type="button" class="btn btn-secondary btn-sm" data-detail-id="${book.id}">Detail</button>
            <button type="button" class="btn btn-primary btn-sm" data-add-id="${book.id}">+ Keranjang</button>
          </div>
        </div>
      </div>
    `;
    el.bookGrid.appendChild(card);
  });
}

function openDetailModal(bookId) {
  const book = getBookById(bookId);
  if (!book) return;

  el.detailCategory.textContent = book.category;
  el.detailCover.style.background = book.gradient;
  el.detailCover.textContent = book.title;
  el.detailTitle.textContent = book.title;
  el.detailAuthor.textContent = `Oleh ${book.author}`;
  el.detailMeta.textContent = `${book.pages} halaman • Format ${book.format}`;
  el.detailSynopsis.textContent = book.synopsis;
  el.detailPrice.textContent = formatRupiah(book.price);
  el.detailAddBtn.dataset.addId = book.id;

  el.detailHighlights.innerHTML = "";
  book.highlights.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    el.detailHighlights.appendChild(li);
  });

  el.detailModal.hidden = false;
  el.detailModalBackdrop.hidden = false;
}

function closeDetailModal() {
  el.detailModal.hidden = true;
  el.detailModalBackdrop.hidden = true;
}

function openCart() {
  el.cartDrawer.hidden = false;
  el.cartBackdrop.hidden = false;
  renderCart();
}

function closeCart() {
  el.cartDrawer.hidden = true;
  el.cartBackdrop.hidden = true;
}

function addToCart(bookId) {
  const book = getBookById(bookId);
  if (!book) return;

  el.checkoutConfirmation.hidden = true;
  const existing = state.cart.find((item) => item.id === book.id);
  if (existing) {
    existing.qty += 1;
  } else {
    state.cart.push({ id: book.id, qty: 1 });
  }
  updateCartBadge();
  renderCart();
}

function changeQty(bookId, delta) {
  const idx = state.cart.findIndex((item) => item.id === Number(bookId));
  if (idx === -1) return;
  state.cart[idx].qty += delta;
  if (state.cart[idx].qty <= 0) {
    state.cart.splice(idx, 1);
  }
  updateCartBadge();
  renderCart();
}

function updateCartBadge() {
  const totalQty = state.cart.reduce((sum, item) => sum + item.qty, 0);
  el.cartCount.textContent = String(totalQty);
}

function renderCart() {
  el.cartItems.innerHTML = "";

  if (state.cart.length === 0) {
    el.cartItems.innerHTML = `
      <div class="cart-empty">
        <p>Keranjang belanja Anda masih kosong.</p>
        <p>Pilih e-book di katalog untuk mulai menambahkan.</p>
      </div>
    `;
  } else {
    state.cart.forEach((entry) => {
      const book = getBookById(entry.id);
      if (!book) return;
      const row = document.createElement("div");
      row.className = "cart-item";
      row.innerHTML = `
        <div>
          <h4>${book.title}</h4>
          <small>${formatRupiah(book.price)} &times; ${entry.qty}</small>
        </div>
        <div class="qty-controls">
          <button type="button" class="qty-btn" data-qty-id="${book.id}" data-delta="-1" aria-label="Kurangi jumlah">&minus;</button>
          <span>${entry.qty}</span>
          <button type="button" class="qty-btn" data-qty-id="${book.id}" data-delta="1" aria-label="Tambah jumlah">+</button>
        </div>
      `;
      el.cartItems.appendChild(row);
    });
  }

  const subtotal = state.cart.reduce((sum, entry) => {
    const book = getBookById(entry.id);
    return sum + (book ? book.price * entry.qty : 0);
  }, 0);

  const discountRate = state.promoCode && PROMO_CODES[state.promoCode] ? PROMO_CODES[state.promoCode] : 0;
  const discountAmount = Math.round(subtotal * discountRate);
  const total = Math.max(0, subtotal - discountAmount);

  el.subtotalText.textContent = formatRupiah(subtotal);

  if (discountAmount > 0) {
    el.discountRow.hidden = false;
    el.appliedPromoCode.textContent = state.promoCode;
    el.discountText.textContent = "-" + formatRupiah(discountAmount);
  } else {
    el.discountRow.hidden = true;
  }

  el.totalText.textContent = formatRupiah(total);
}

// Event Listeners
el.categoryPills.forEach((pill) => {
  pill.addEventListener("click", () => {
    el.categoryPills.forEach((p) => p.classList.remove("active"));
    pill.classList.add("active");
    state.category = pill.dataset.category;
    renderBooks();
  });
});

el.searchInput.addEventListener("input", (e) => {
  state.search = e.target.value;
  renderBooks();
});

el.resetFilterBtn.addEventListener("click", () => {
  state.category = "Semua";
  state.search = "";
  el.searchInput.value = "";
  el.categoryPills.forEach((p) => p.classList.toggle("active", p.dataset.category === "Semua"));
  renderBooks();
});

document.addEventListener("click", (e) => {
  const addTarget = e.target.closest("[data-add-id]");
  if (addTarget) {
    addToCart(addTarget.dataset.addId);
    openCart();
    return;
  }

  const detailTarget = e.target.closest("[data-detail-id]");
  if (detailTarget) {
    openDetailModal(detailTarget.dataset.detailId);
    return;
  }

  const qtyTarget = e.target.closest("[data-qty-id]");
  if (qtyTarget) {
    changeQty(qtyTarget.dataset.qtyId, Number(qtyTarget.dataset.delta));
  }
});

el.previewFeaturedBtn.addEventListener("click", () => openDetailModal(1));
el.closeDetailBtn.addEventListener("click", closeDetailModal);
el.detailModalBackdrop.addEventListener("click", closeDetailModal);
el.detailAddBtn.addEventListener("click", () => {
  const id = el.detailAddBtn.dataset.addId;
  closeDetailModal();
  addToCart(id);
  openCart();
});

el.openCartBtn.addEventListener("click", openCart);
el.closeCartBtn.addEventListener("click", closeCart);
el.cartBackdrop.addEventListener("click", closeCart);

el.promoForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const code = el.promoInput.value.trim().toUpperCase();
  if (!code) {
    state.promoCode = null;
    el.promoFeedback.textContent = "Masukkan kode promo terlebih dahulu.";
    renderCart();
    return;
  }

  if (PROMO_CODES[code]) {
    state.promoCode = code;
    el.promoFeedback.textContent = `Kode ${code} diterapkan (diskon 20%).`;
  } else {
    state.promoCode = null;
    el.promoFeedback.textContent = "Kode promo tidak valid. Coba gunakan HEMAT20.";
  }
  renderCart();
});

el.checkoutBtn.addEventListener("click", () => {
  if (state.cart.length === 0) {
    el.checkoutConfirmation.hidden = false;
    el.checkoutConfirmation.textContent = "Tambahkan minimal satu e-book ke keranjang sebelum melanjutkan pemesanan.";
    return;
  }

  const summaryItems = state.cart
    .map((item) => {
      const book = getBookById(item.id);
      return book ? `${book.title} (${item.qty}x)` : "";
    })
    .filter(Boolean)
    .join(", ");

  el.checkoutConfirmation.hidden = false;
  el.checkoutConfirmation.textContent = `Ringkasan pesanan siap: ${summaryItems}. Anda dapat menghubungkan tombol ini ke WhatsApp, formulir pesanan, atau payment gateway klien.`;
});

el.menuToggle.addEventListener("click", () => {
  const expanded = el.menuToggle.getAttribute("aria-expanded") === "true";
  el.menuToggle.setAttribute("aria-expanded", String(!expanded));
  el.mobileNav.hidden = expanded;
});

el.mobileNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    el.menuToggle.setAttribute("aria-expanded", "false");
    el.mobileNav.hidden = true;
  });
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeDetailModal();
    closeCart();
  }
});

renderBooks();
updateCartBadge();
renderCart();
