# LenteraPustaka — Template Website Toko E-Book

Template website statis untuk platform jual beli e-book yang siap diunggah ke GitHub dan dipublikasikan melalui **GitHub Pages**.

## Struktur Berkas

```text
lenterapustaka-site/
├── index.html
├── assets/
│   ├── style.css
│   └── app.js
└── README.md
```

## Cara Publikasi di GitHub Pages

1. Buat repositori baru di GitHub (misalnya `lenterapustaka-ebook`).
2. Unggah seluruh isi folder `lenterapustaka-site/` ke cabang `main`.
3. Buka tab **Settings** pada repositori, pilih menu **Pages**.
4. Pada bagian **Build and deployment**, pilih **Deploy from a branch**, lalu pilih cabang `main` dan folder `/ (root)`.
5. Simpan pengaturan dan tunggu beberapa saat hingga tautan situs aktif.

## Cara Menyesuaikan Konten untuk Klien

- **Identitas & Brand**: Ubah nama merek, kontak, dan teks bagian hero di `index.html`.
- **Daftar E-Book & Harga**: Sunting array `BOOKS` di `assets/app.js` untuk mengganti judul, penulis, kategori, harga, sinopsis, dan poin utama.
- **Kode Promo**: Atur kode diskon pada objek `PROMO_CODES` di `assets/app.js`.
- **Warna & Tipografi**: Sesuaikan variabel CSS pada blok `:root` di `assets/style.css`.
